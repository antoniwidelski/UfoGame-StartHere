All env map/images contained in this zip file are (c) 1999 by Adam W. Stiles.  They may be used publicly for mods, etc. as long as the following conditions are met:

1)  I am somehow given credit for the env map(s) / image(s) that is/are used.  If it/they is/are used in a modification, then a line giving credit to me must be included somwhere in your distribution of the mod.  I.e. give credit where it's due ;)

2) If the env maps / images are used in a modification, please send me an email letting me know about it.  More for personal purposes - I'd really like to see first hand any mod that uses some of my env maps :)

That being said - this zip file should contain 7 files:

	- 6 images (16 million colors) for the complete sky box all in TGA format
	- The text file you are currently reading
	
If it doesn't contain those - then you didn't get it from me.  In this event please send me an email (address below) letting me know where you acquired the file(s).

Send all questions/comments and/or requests and suggestions to:

Adam W. Stiles
email :  muad@twcny.rr.com
	